# 2IMTSL
Algorithm, code and paper about the 2IMTSL learner
